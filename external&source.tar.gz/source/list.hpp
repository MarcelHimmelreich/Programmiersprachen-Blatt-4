// list.hpp (Programmiersprachen Aufgabe 4)

#ifndef BUW_LIST_HPP 
#define BUW_LIST_HPP
#include <cstddef>
#include <utility> 

    //Aufgabe 4.1
template <typename T>
class List;

template <typename T>
struct ListNode 
{
  ListNode() : m_value(), m_prev(nullptr), m_next(nullptr) {}
  ListNode(T const& v, ListNode* prev, ListNode* next) : 
  m_value(v), m_prev(prev), m_next(next) {}

  T m_value;
  ListNode* m_prev;
  ListNode* m_next;
};

template <typename T>
struct ListIterator {
  friend class List<T>;

	typedef ListIterator <T> Self ;
	typedef T value_type ;
	typedef T * pointer ;
	typedef T & reference ;
	typedef ptrdiff_t difference_type ;
	typedef std::forward_iterator_tag iterator_category ;


	ListIterator():  m_node{nullptr} {} 
	ListIterator( ListNode <T> *n ): m_node{n} {} 


	
		//Aufgabe 4.4
	reference operator* () const 
	{
		return m_node->m_value;
	} 
	pointer operator ->() const 
	{
		return &(m_node->m_value);
	} 
	Self & operator ++() //++i
	{
		if (m_node)
		  {
        m_node = m_node -> m_next;
      }
		return *this;
	} 
	Self operator ++( int ) //i++
	{
		ListIterator tmp(*this);

		if (m_node) m_node = m_node -> m_next;
		
		return tmp;
	}

		//Aufgabe 4.6
	bool operator ==( const Self & x ) const 
	{
		return (m_node == x.m_node);
	} 
	bool operator !=( const Self & x ) const 
	{
		return m_node != x.m_node;
	} 
	Self next() const
	{
		if (m_node) return ListIterator (m_node -> m_next);
		else        return ListIterator (nullptr);
	}

	Self prev() const
	{
		if (m_node) return ListIterator (m_node->m_prev);
		else        return ListIterator (nullptr);
	}

private:
  ListNode<T>* m_node = nullptr;
};

template <typename T>
struct ListConstIterator 
{
  friend class List<T>;
public:

private:
  ListNode<T>* m_node = nullptr;
};

		//Aufgabe 4.1
template <typename T>
class List {
public: 
  // Default Constructor
  typedef T value_type;
  typedef T* pointer;
  typedef const T* const_pointer;
  typedef T& reference; 
  typedef const T& const_reference;
  typedef ListIterator<T> iterator; 
  typedef ListConstIterator<T> const_iterator;

  friend class ListIterator<T>;
  friend class ListConstIterator<T>;

    //Aufgabe 4.1
  List(): m_size{0}, m_first{nullptr}, m_last{nullptr} {} 

      //Aufgabe 4.7
  List(List<T> const& Clist): m_size{0}, m_first{nullptr}, m_last{nullptr} {
    for(iterator i = Clist.begin(); i!=Clist.end(); ++i)
    {
      push_back(*i);
    }

  }

      //Aufgabe 4.12
  List(List&& list_move): m_size {list_move.m_size}, m_first {list_move.m_first}, m_last {list_move.m_last} 
  { 
    list_move.m_size = 0;
    list_move.m_first = nullptr;
    list_move.m_last = nullptr; 
  }

    //Aufgabe 4.1
  bool empty() const 
  {
    return m_size == 0;
  }

  std::size_t size() const 
  {
    return m_size;
  }

		//Aufgabe 4.2
  T const& front() const 
  {
    return (*m_first).m_value;
  }

  T& front() 
  {
    return (*m_first).m_value;
  }

  T const& back() const
  {
    return (*m_last).m_value;
  }

  T& back()
  {
    return (*m_last).m_value;   
  }

  void push_front(T const& a) 
  {
    if (m_size == 0) 
    {
      m_first = new ListNode<T>{a, nullptr, nullptr};
      m_last = m_first;
    }

    else if (m_size >= 1) 
    {
      m_first = new ListNode<T>{a, nullptr, m_first};
      m_first -> m_next -> m_prev = m_first;
    }

    ++m_size; 
  }

  void push_back(T const& a)
  {
    if (m_size == 0) 
    {
      m_last = new ListNode<T>{a, nullptr, nullptr};
      m_first = m_last;
    }

    else if (m_size >= 1) 
    {
      m_last = new ListNode<T>{a, m_last, nullptr};
      m_last -> m_prev -> m_next = m_last;
    }

    ++m_size;
  }

  void pop_front()
  {
    if (m_size == 1) 
    {
      assert(m_first != nullptr);
      delete m_first;
      m_first = nullptr;
      m_size = 0;
    }

    else if (m_size > 1) 
    {
      assert(m_first != nullptr);
      delete m_first;
      m_first = m_first -> m_next;
      --m_size;
    }
  }

  void pop_back()
  {
   if (m_size == 1)
   {
      assert(m_last != nullptr);
      delete m_last;
      m_last = nullptr;
      m_size = 0;
    }

    else if (m_size > 1) 
    {
      assert(m_last != nullptr);
      delete m_last;
      m_last = m_last -> m_prev;
      --m_size;
    }

  }
		//Aufgabe 4.3
  void clear()
  {
    while(m_size > 0)
    {
      pop_back();
    }

  }

		//Aufgabe 4.5
  iterator begin() const {
    return iterator {m_first};
  }

  iterator end() const {
    return iterator {};
  }

		//Aufgabe 4.8
void insert(iterator pos, T const& value)
{
	if (pos==begin())
	{
		push_front(value);
	}
	else if(pos==end())
	{
		push_back(value);
	}
	else 
	{
		ListNode <T>* newnode= new ListNode<T>{value, pos.prev().m_node, pos.m_node};
		pos.prev().m_node->m_next = newnode;
		pos.m_node->m_prev = newnode;
		++m_size;
	}
}

		//Aufgabe 4.9
void reverse()
{
	List<T> rev{*this};
	clear();
	for(iterator i = rev.begin(); i!=rev.end(); i++)
	{
		push_front(*i);
	}
}

    //Aufgabe 4.3
  ~List() 
  {
    clear();
  }
 
private:
  std::size_t m_size = 0;
  ListNode<T>* m_first = nullptr;
  ListNode<T>* m_last = nullptr;
};

template < typename T >
	bool operator ==( List <T> const & xs , List <T > const & ys )
	{
		if(xs.size() != ys.size()){return false;}
		else
		{
			ListIterator<T> x = xs.begin();
			ListIterator<T> y = ys.begin();
			while(x!= xs.end() and y!= ys.end())
			{
				if(*x != *y)
          {
            return false;
          }
				
				x++;
				y++;
			}
		}
		return true;
	}

template <typename T>
	bool operator !=( List <T> const & xs , List <T> const & ys )
	{
		return ! (xs==ys);	
	}

    //Aufgabe 4.9
  template<typename T>
List<T> reverse (List<T> revList) {
  revList.reverse();
  return revList;
}

#endif // #define BUW_LIST_HPP

// TestList.cpp (Programmiersprachen Aufgabe 4

#define CATCH_CONFIG_RUNNER
#include <catch.hpp>
#include <cmath>
#include <algorithm>
#include "list.hpp"


TEST_CASE("describe_List_empty", "[list_empty]") 
{
	List<int> l1 {};
	REQUIRE(l1.empty() == true);
}

TEST_CASE("describe_List_size", "[list_size]") 
{
	List<int> l1 {};
	REQUIRE(l1.size() == 0);
}

TEST_CASE("add an element with push_front", "[push_front]") 
{
    List<int> list {}; 
    list.push_front(42); 
    REQUIRE(42 == list.front());

    List<int> l2;
  	l2.push_front(1);
  	l2.push_front(2);
  	l2.push_front(3);
  	REQUIRE(3 == l2.front());
}

TEST_CASE("add an element with push_back","[push_back]") 
{
	List<int> list {};
	list.push_back(42);
	REQUIRE(42 == list.back() );

	List<int> l2 {};
  	l2.push_back(1);
  	l2.push_back(2);
  	l2.push_back(3);
  	REQUIRE(3 == l2.back());
}

TEST_CASE("delete an element with pop_front" , "[pop_front]")
{
	List<int> list {};
	list.push_back(1);
  	list.push_back(2);
	list.pop_front();
	REQUIRE(2 == list.front() );

	List<int> listempty {};
	listempty.push_front(1);
	listempty.pop_front();
	REQUIRE(true == listempty.empty() );
}

TEST_CASE("delete an element with pop_back" , "[pop_back]")
{
	List<int> list {};
	list.push_back(1);
  	list.push_back(2);
	list.pop_back();
	REQUIRE(1 == list.back() );

	List<int> listempty {};
	listempty.push_front(1);
	listempty.pop_back();
	REQUIRE(true == listempty.empty() );
}

TEST_CASE("front","[front]")
{
	List<int> list {};
	list.push_front(1); 
  	list.push_front(2); 
  	list.push_front(3); 
  	list.push_front(4); 
	REQUIRE(4==list.front());
}

TEST_CASE("back","[back]")
{
	List<int> list {};
	list.push_front(5); 
  	list.push_front(2); 
  	list.push_front(3); 
  	list.push_front(4); 
	REQUIRE(5==list.back());
}


TEST_CASE("should be empty after clearing", "[modifiers]") 
{
  List<int> list; 
  list.push_front(1); 
  list.push_front(2); 
  list.push_front(3); 
  list.push_front(4); 
  list.clear(); 
  REQUIRE(list.empty());
}

TEST_CASE("should be an empty range after default construction", "[iterators]") {
  List<int> list;
  auto b = list.begin(); 
  auto e = list.end(); 
  REQUIRE(b == e);
}

TEST_CASE("provide access to the first element with begin", "[iterators]") {
  List<int> list; 
  list.push_front(42); 
  REQUIRE(42 == *list.begin());
}

TEST_CASE("Checks if equal","[equal]")
{
	List<int> list{};
  	list.push_front(1); 
  	list.push_front(2); 
  	list.push_front(3); 
  	list.push_front(4);	
	List<int> list1{};
  	list1.push_front(1); 
  	list1.push_front(2); 
  	list1.push_front(3); 
  	list1.push_front(4);	
	REQUIRE(list == list1);

	List<int> list2{};
	List<int> list3{};
	REQUIRE(list2 == list3);

}

TEST_CASE("Checks if different","[different]")
{
	List<int> list{};
  	list.push_front(1); 
  	list.push_front(1); 
  	list.push_front(3); 
  	list.push_front(4);	
	List<int> list1{};
  	list1.push_front(1); 
  	list1.push_front(2); 
  	list1.push_front(3); 
  	list1.push_front(4);
	REQUIRE(list != list1);

	List<int> list2{};
  	list2.push_front(1); 
	List<int> list3{};
	REQUIRE(list2 != list3);

}

TEST_CASE("çopy constructor","[copy]")
{
	List<int> list{};
  	list.push_front(3); 
  	list.push_front(2); 
  	list.push_front(1); 	
	List<int> list1{list};
	REQUIRE(list == list1);

}

TEST_CASE("Test for insert","[insert]")
{
	List<int> list;
  	list.push_front(1); 
  	list.push_front(2); 
  	list.push_front(3); 
  	list.push_front(4); 
  	list.push_front(5);	
	list.insert(list.begin(), 6);
	REQUIRE(6 == list.size());
	REQUIRE(6 == list.front());
	REQUIRE(1 == list.back());

	List<int> list1;
  	list1.push_front(1); 
  	list1.push_front(2); 
  	list1.push_front(3); 
  	list1.push_front(4); 
  	list1.push_front(5);	
	list1.insert(list1.end(), 8);
	REQUIRE(6 == list1.size());
	REQUIRE(5 == list1.front());
	REQUIRE(8 == list1.back());

	List<int> list2;
  	list2.push_front(5); 
  	list2.push_front(4); 
  	list2.push_front(3); 
  	list2.push_front(2); 
  	list2.push_front(1); //1,2,3,4,5
	ListIterator<int> pos =list2.begin();
	pos++;
  	++pos;
  	++pos; 
  	list2.insert(pos, 8);
  	REQUIRE(6 == list2.size());
  	REQUIRE(1 == list2.front());
  	REQUIRE(5 == list2.back());
  	ListIterator<int> it = list2.begin();
  	REQUIRE(1 == *it);
  	++it; 
  	REQUIRE(2 == *it); 
  	++it;
  	REQUIRE(3 == *it);
  	++it;
  	REQUIRE(8 == *it); 

}

TEST_CASE("Copy with std::vector","[copy_vector]")
{
	List<int> list{};
  	list.push_front(5); 
  	list.push_front(4); 
  	list.push_front(3); 
  	list.push_front(2); 
  	list.push_front(1);	
	std::vector<unsigned int> Lvector(list.size());
	std::copy(list.begin(),list.end(), std::begin(Lvector));

	REQUIRE(1 == Lvector[0]);
	REQUIRE(2 == Lvector[1]);
	REQUIRE(3 == Lvector[2]);
	REQUIRE(4 == Lvector[3]);
	REQUIRE(5 == Lvector[4]);
}

TEST_CASE("move constructor", "[constructor]") 
{
  List<int> list;
  list.push_front(1);
  list.push_front(2);
  list.push_front(3);
  list.push_front(4);

  List<int> list2(std::move(list));
  REQUIRE(0 == list.size());
  REQUIRE(list.empty());
  REQUIRE(4 == list2.size());
}

TEST_CASE("reverses the sequence of the list", "[reverse]") {
  List<int> list; 
  list.push_back(1); 
  list.push_back(2); 
  list.push_back(3); 
  list.push_back(4); 
  list.push_back(5);
  list.reverse();
  ListIterator<int> it = list.begin();
  REQUIRE(5 == *it);
  ++it;
  REQUIRE(4 == *it);
  ++it; 
  REQUIRE(3 == *it);
  ++it;
  REQUIRE(2 == *it);
  ++it; 
  REQUIRE(1 == *it);

  reverse(list);
  ListIterator<int> i = list.begin();
  REQUIRE(5 == *i);
  ++i;
  REQUIRE(4 == *i);
  ++i; 
  REQUIRE(3 == *i);
  ++i;
  REQUIRE(2 == *i);
  ++i; 
  REQUIRE(1 == *i);

}


int main(int argc, char * argv[]) 
{
  return Catch::Session().run(argc, argv);
}

